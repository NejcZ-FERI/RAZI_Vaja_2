<p>Oglas je bil uspešno shranjen!</p>
<p>Viden je <a href="?controller=ads&action=show&id=<?php echo $ad->id; ?>">tukaj</a></p>