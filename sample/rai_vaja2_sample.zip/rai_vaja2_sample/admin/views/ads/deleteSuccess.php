<p>Oglas je bil uspešno izbrisan!</p>
<a href="?controller=ads&action=index"><button>Nazaj</button></a>