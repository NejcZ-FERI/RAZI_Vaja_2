<?php
/*
    Prazna datoteka, ki simulira model za 'pages_controller'.
    Potrebujemo jo, ker bi sicer dobili napako pri dinamičnem nalaganju datotek v funkciji call (routes.php).
    Kot alternativa, bi lahko modele nalagali v controllerjih, namesto v funkciji call. Potem te datoteke ne bi potrebovali.
*/
